#include<stdio.h>
int main()
{
	auto int a;
	printf("%d",a);
}
