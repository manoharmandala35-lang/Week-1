#include<stdio.h>
int main()
{
	printf("Result=30");
}